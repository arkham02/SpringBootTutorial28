package com.in28minutes.springboot.web.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@Controller("error")
public class ExceptionController {
	
	@ExceptionHandler(RuntimeException.class)
	public ModelAndView handleException(HttpServletRequest httpServletRequest, RuntimeException e) {
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("url", httpServletRequest.getRequestURL());
		modelAndView.addObject("exception", e.getStackTrace());
		modelAndView.setViewName("error");
		return modelAndView;
	}
}
