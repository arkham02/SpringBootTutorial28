package com.prd.infosys.springboothandson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHandsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHandsonApplication.class, args);
	}
}
