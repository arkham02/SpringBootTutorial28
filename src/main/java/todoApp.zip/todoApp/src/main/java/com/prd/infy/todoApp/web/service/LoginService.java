package com.prd.infy.todoApp.web.service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {

	public boolean validateUser(String username, String password) {
		if (username.equals("admin") && password.equals("admin"))
			return true;
		else
			return false;
	}
}
