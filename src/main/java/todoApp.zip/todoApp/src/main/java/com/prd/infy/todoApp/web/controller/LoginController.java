package com.prd.infy.todoApp.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.prd.infy.todoApp.web.service.LoginService;
import com.prd.infy.todoApp.web.service.TodoService;

@Controller
public class LoginController {

	@Autowired
	LoginService loginService;
	
	@Autowired
	TodoService todoService;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String showLoginPage() {
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String handleLogin(ModelMap modelMap, @RequestParam String name, @RequestParam String password) {
		boolean isValidUser = loginService.validateUser(name, password);

		if (isValidUser) {
			modelMap.put("name", name);
			modelMap.put("todos", todoService.retrieveTodos("in28Minutes"));
			return "welcome";
		} else {
			modelMap.put("errorMessage", "Invalid Credentials!!");
			return "login";
		}
	}

}
